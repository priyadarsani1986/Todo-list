export interface Tasks{
    id: number,
    title: string,
    completed: boolean,
    editing:boolean
}